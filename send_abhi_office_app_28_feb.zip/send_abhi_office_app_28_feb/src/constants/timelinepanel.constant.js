export const timeSliderConst = {
    timeDiffrence : 1 , // time diffrence present on timeline its in minute
    zoomTimeDiffrence : 1, // how much zoom will happen its in minute
}

export const sourceThumbnailListConst = {

}

export const ThumbListConst ={
    MINZOOM : 1,
    MAXZOOM : 4,
    ZOOM1 : 1,
    ZOOM2 : 5,
    ZOOM3 : 20,
    ZOOM4 : 60,
}