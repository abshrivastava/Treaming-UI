<template>
  <header>
    <div class="logo">
      <span class="logo-circle">TVU</span>
      <span>Editor</span>
    </div>
    <div class="profile">
      <span class="logo-circle">User</span>
    </div>
  </header>
</template>

<script>
export default {
  name: "HeaderComp"
};
</script>

<style>
</style>