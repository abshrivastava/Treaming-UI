<template>
<div class="internal" :id= "'a'+src">
<img :src="src || '../../assets/images/scene.jpg'">
</div>
</template>

<script>
export default {
    name: 'SourceThumbnailItem',
    props:{
        baseurl : String,
        source : Number
    },
    data(){
        return {src : this.baseurl ? (this.baseurl + this.source + ".jpg") : "",};
    }

}
</script>

<style lang="">
    .internal img{
        width:85px;
	    height:75px;
    }

    .internal{
         width:85px;
 height: 100%;
 display: inline-block;
}
</style>