<template>
<div class="video-thumbnail">
    <div class="name">1. Source Name</div>
    <img :src="src || '../../assets/images/scene.jpg'" />
</div>
</template>

<script>
export default {
    name: 'RecordThumbnail',
    props: {
        baseurl: String,
        source: Number
    },
    data() {
        return {
            src: this.baseurl ? (this.baseurl + this.source + ".jpg") : "",
        };
    }

}
</script>

<style >
.video-thumbnail{
	margin-right:3%;
	position:relative;
}
.video-thumbnail .name{
	position:absolute;
	top:0;
	left:0;
	background:rgba(0,0,0,.5);
	color:#fff;
	font-size:11px;
	font-weight:600;
	padding:5px
}
.video-thumbnail img{
	width:150px;
    height: 75px;
}
</style>
