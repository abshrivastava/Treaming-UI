<template>
  <div class="play-video">
    <div class="btn-row text-right">
      <button @click="justSave()" class="link-btn">Just Save</button>
      <button class="btn-green btn-big">Ready</button>
    </div>
    <img src="../../assets/images/video-b.png" class="image-responsive">
    <div class="btn-row flex-v-center">
      Transition
      <span class="transition-color"></span>
    </div>
  </div>
</template>

<script>
import EventBus from "../common/event-bus";
import { workbenchModel } from "../../models/workbench.model";
import { storyActions } from "../../actions/story.action";

export default {
  name: "storypreviewpanel",
  methods: {
       /**
       * Description: Save Story
       */
      justSave: function() {  
        if(workbenchModel.MODEL.items.length <= 0) {
          alert("No story or scene selected")
          return
        } 
        
        workbenchModel.MODEL.items.map((scene) => {
           return delete scene.index
        })

        if(workbenchModel.MODEL.editMode === true) {
          let item = { 
                      "ID": workbenchModel.MODEL.editStoryId, 
                      "Title": "Nice", 
                      "Scenes":workbenchModel.MODEL.items,
                      // "FrontCover":"8200/Thumbnails/0db8ebca-c6be-47f5-9b95-67085ff854e8/Default/ThumbNail/"+workbenchModel.MODEL.items[0].StartTimestamp
                      "FrontCover":null
                    }    
          new Promise((resolve) => {
              storyActions.editStory(JSON.stringify(item))
              resolve()
            })
            .then(()=>{
                EventBus.$emit("resetWorkbench")
                EventBus.$emit("resetPopup")
                EventBus.$emit("refreshComponent")
                alert("Story Edited")
            })
            .catch((error) => {
                console.log(error)
            }) 
        }
        if(workbenchModel.MODEL.editMode === false) {
            let item = { 
                          "Title": "Nice", 
                          "Tags": [], 
                          "Author": "editor@pp.com",
                          "Scenes":workbenchModel.MODEL.items,
                          // "FrontCover":"8200/Thumbnails/0db8ebca-c6be-47f5-9b95-67085ff854e8/Default/ThumbNail/"+workbenchModel.MODEL.items[0].StartTimestamp
                          "FrontCover":null
                        }   
            new Promise((resolve) => {
              storyActions.addStory(JSON.stringify(item))
              resolve()
            })
            .then(()=>{
                EventBus.$emit("resetWorkbench")
                EventBus.$emit("resetPopup")
                EventBus.$emit("refreshComponent")
                alert("Story Saved")
            })
            .catch((error) => {
                console.log(error)
            }) 
        }          
        
      },
      
  }
};
</script>

<style>
</style>